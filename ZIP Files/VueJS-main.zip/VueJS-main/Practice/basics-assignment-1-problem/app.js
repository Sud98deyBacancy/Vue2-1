const app = Vue.createApp({
	data() { return {username:'Sudarshan',Age:22,mediaURL:'https://thumbs-prod.si-cdn.com/ZxCkpK3AUveoAoqqjZbgPh1eJ2k=/fit-in/1072x0/https://public-media.si-cdn.com/filer/6f/01/6f019763-6ead-4ae3-a3de-be0dbcb72a7c/89f93f0728e02b49a4b7a591ecaa0ba218651ab9jpg1072x0_q85_upscale.jpg' };  }
});
app.mount('#assignment')